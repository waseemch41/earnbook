const eslintrc = require('../../.eslintrc.js');

module.exports = eslintrc;
